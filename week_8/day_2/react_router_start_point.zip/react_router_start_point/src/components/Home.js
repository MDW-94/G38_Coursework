import React from "react";

const Home = () => (
  <div>
    <h4>Home</h4>
    <p>Welcome to our magical homepage</p>
  </div>
);

export default Home;
