import React from 'react'

const ErrorPage = () => {
    
    return ( 
        <h1>404 - PAGE NOT FOUND</h1>
     );
}
 
export default ErrorPage;