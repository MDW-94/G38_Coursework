import React, {useEffect, useState} from 'react';
import ListProducts from '../components/ListProducts';

const EcommerceContainer = ({OriginalProducts}) => {

    return( 
        <div>
        </div>
      );
}
 
export default EcommerceContainer;