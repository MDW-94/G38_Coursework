import React from 'react';

const Error = () => {
    return (
        <div>
            <h1>OOPS something went wrong!</h1>
        </div>
      );
}
 
export default Error;