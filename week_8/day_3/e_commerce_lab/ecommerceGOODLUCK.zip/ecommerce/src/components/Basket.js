import React from 'react';
import BasketItem from './BasketItem';

const Basket = ({basket}) => {
    if (basket == null || basket.length === 0){
        return <p>You should really buy something...</p>
    }

    const BasketItems = basket.map((product, index) => {
        return <BasketItem key={index} product={product}/>
    })
    return (
        <div>
            {BasketItems}
        </div>
      );
}
 
export default Basket;