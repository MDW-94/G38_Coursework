import React from 'react';


const ListItem = ({index, product, handleInputChange}) => {

    const handleClick = (event) => {
        console.log(event.target.value)
        handleInputChange(event.target.value)


    };
    
    return (
        <div>
            <ul>
                {product.name}, £{product.price}
                <button onClick={handleClick}
                value={product.id} >Add to Basket</button>
            </ul>
        </div>
      );
}
 
export default ListItem;