import React, { Component } from 'react';

const Home = () => {
    return (
        <div>
            <p>I am the Home page, sup</p>
        </div>
      );
}
 
export default Home;