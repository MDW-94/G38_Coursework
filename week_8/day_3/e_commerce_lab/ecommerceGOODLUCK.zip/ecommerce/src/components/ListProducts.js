import React from 'react';
import ListItem from './ListItem';

const ListProducts = ({products, handleInputChange}) => {

    const ListItems = products.map((product, index) => {
        return <ListItem key={index} product={product} handleInputChange={handleInputChange} />
    })

    return ( 
        <div>
            <h1>I am the Product List</h1>
            {ListItems}
        </div>
        
     );
}
 
export default ListProducts;