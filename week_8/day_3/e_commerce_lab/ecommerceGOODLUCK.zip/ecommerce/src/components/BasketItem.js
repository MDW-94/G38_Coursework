import React from 'react';


const BasketItem = ({index, product}) => {
    
    return (
        <div>
            <ul>
                <li>{product.name}, £{product.price}</li>
            </ul>
        </div>
      );
}
 
export default BasketItem;