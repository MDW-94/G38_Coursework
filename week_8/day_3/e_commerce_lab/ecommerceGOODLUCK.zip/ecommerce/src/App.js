import './App.css';
import React, {useState, useEffect} from 'react';
import {BrowserRouter as Router, Routes, Route} from 'react-router-dom';
import EcommerceContainer from './container/eCommerceContainer';
import Home from './components/Home';
import ListProducts from './components/ListProducts';
import Basket from './components/Basket';
import NavBar from './components/NavBar';
import Error from './components/Error';

function App() {

  const OriginalProducts = [
    {id:1,
    name: "Depresausorus",
    price: 50.00},
    {id:2,
    name: "Stagnationsorus",
    price: 2.00},
    {id:3,
    name: "Postnatal Raptor",
    price: 100.00},
    {id:4,
    name:"Toure-rex",
    price: 3.33},
    {id:5,
    name:"O C Dino",
    price: 99.79}
  ]

    const [products, setProducts] = useState([OriginalProducts])
    const [basket, setBasket] = useState([])
    // const [selectedItem, setSelectedItem] = useState([])

    console.log(basket)

    useEffect(() =>{
    setProducts(OriginalProducts)
    },[setBasket])

    const AddToBasket = (input) => {
      const updatedBasket = [...basket, input];
      setBasket(updatedBasket);
      console.log(updatedBasket)
    };

    const handleInputChange = (id) => {
      const itemToAdd = products.find((product) => id == product.id)
      AddToBasket(itemToAdd)
    }

  return (
    <div className="App">
      <Router>
        <NavBar/>
        <Routes>
          <Route path="/" element={<Home/>}/>
          
          <Route path="/products" element={<ListProducts products={products} handleInputChange={handleInputChange} />}/>
          
          <Route path="/basket" element={<Basket basket={basket}/>}/>
          
          <Route path="*" element={<Error/>}/>
        </Routes>
      </Router>
      <EcommerceContainer OriginalProducts={OriginalProducts}/>
    </div>
  );
}

export default App;
